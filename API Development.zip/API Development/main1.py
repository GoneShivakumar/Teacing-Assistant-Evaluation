import pymysql
from app import app
from config import mysql
from flask import jsonify
from flask import flash, request

@app.route('/create', methods=['POST'])
def create_TA():
    # code to create TA record
    try:        
        _json = request.json
        _native_english_speaker = _json['native_english_speaker']
        _course_instructor = _json['course_instructor']
        _course = _json['course']
        _semester = _json['semester']	
        _class_size = _json['class_size']
        _performance_score = _json['performance_score']
        if _native_english_speaker and _course_instructor and _course and _semester and _class_size and _performance_score and request.method == 'POST':
            conn = mysql.connect()
            cursor = conn.cursor(pymysql.cursors.DictCursor)		
           
            sqlQuery = "INSERT INTO TA(native_english_speaker, course_instructor, course, semester, class_size, performance_score) VALUES(%s, %s, %s, %s,%s, %s)"
            bindData = (_native_english_speaker, _course_instructor, _course, _semester, _class_size, _performance_score )            
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            respone = jsonify('Teaching Assistant added successfully!')
            respone.status_code = 200
            return respone
        else:
            return showMessage()
    except Exception as e:
        print(e)
    finally:
        cursor.close() 
        conn.close() 

@app.route('/TA',methods=['GET'], endpoint='TA_info')
def TA():
    # code to retrieve all TA records
    try:
        conn = mysql.connect()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT id, native_english_speaker, course_instructor, course, semester, class_size, performance_score FROM TA")
        TARows = cursor.fetchall()
        respone = jsonify(TARows)
        respone.status_code = 200
        return respone
    except Exception as e:
        print(e)
    finally:
        cursor.close() 
        conn.close()

@app.route('/TA/<int:TA_id>',methods=['GET'],endpoint='TA_Rowinfo')
def TA_details(TA_id):
    # code to retrieve a specific TA record
    try:
        conn = mysql.connect()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT id, native_english_speaker, course_instructor, course, semester, class_size, performance_score FROM TA WHERE id =%s", TA_id)
        TARow = cursor.fetchone()
        respone = jsonify(TARow)
        respone.status_code = 200
        return respone
    except Exception as e:
        print(e)
    finally:
        cursor.close() 
        conn.close()

@app.route('/update', methods=['PUT'],endpoint='upd_TA_info')
def update_TA():
    # code to update an existing TA record
    try:
        _json = request.json
        _id = _json['id']
        _native_english_speaker = _json['native_english_speaker']
        _course_instructor = _json['course_instructor']
        _course = _json['course']
        _semester = _json['semester']	
        _class_size = _json['class_size']
        _performance_score = _json['performance_score']
        if _native_english_speaker and _course_instructor and _course and _semester and _class_size and _performance_score and request.method == 'PUT':			
            sqlQuery = "UPDATE TA SET native_english_speaker=%s, course_instructor=%s, course=%s, semester=%s, class_size=%s, performance_score=%s WHERE id=%s"
            bindData = (_native_english_speaker, _course_instructor, _course, _semester, _class_size, _performance_score, _id )
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            respone = jsonify('TA updated successfully!')
            respone.status_code = 200
            return respone
        else:
            return showMessage()
    except Exception as e:
        print(e)
    finally:
        cursor.close() 
        conn.close()

@app.route('/delete/<int:id>', methods=['DELETE'],endpoint='del_TA_info')
def delete_TA(id):
    # code to delete an existing TA record
    try:
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM TA WHERE id =%s", (id,))
        conn.commit()
        respone = jsonify('TA deleted successfully!')
        return respone
    except Exception as e:
        print(e)
    finally:
        cursor.close() 
        conn.close() 

@app.errorhandler(404)
def showMessage(error=None):
    message = {
        'status': 404,
        'message': 'Record not found: ' + request.url,
    }
    respone = jsonify(message)
    respone.status_code = 404
    return respone
        
if __name__ == "__main__":
    app.run()
